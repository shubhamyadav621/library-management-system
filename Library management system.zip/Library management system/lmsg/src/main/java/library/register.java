package library;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class register
 */
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		 String jdbcUrl = "jdbc:mysql://localhost:3306/library";

	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        try (Connection connection = DriverManager.getConnection(jdbcUrl, "root", "Ijustturned@18")) {
	            String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
	            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	                preparedStatement.setString(1, username);
	                preparedStatement.setString(2, password);
	                preparedStatement.executeUpdate();
	            }

	            // You can add further logic or redirect the user to a success page
	            PrintWriter out = response.getWriter();
	            response.sendRedirect("2nd.jsp");
	            out.println("<html><body><h2>Registration successful!</h2></body></html>");

	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle errors or redirect the user to an error page
	            PrintWriter out = response.getWriter();
	            out.println("<html><body><h2>Registration failed. Please try again later.</h2></body></html>");
	        }
	    }
	}

